print("Hello World")
name = input("Enter your name\n")
print("Hello", name)
input("press Enter to exit") 